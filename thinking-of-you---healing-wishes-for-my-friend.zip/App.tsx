import React, { useState, useEffect } from 'react';
import { SUPPORTIVE_MESSAGES } from './constants'; 
import { SupportiveMessageCard } from './components/SupportiveMessageCard'; // Updated import

const App: React.FC = () => {
  const [currentMessage, setCurrentMessage] = useState<string>('');

  useEffect(() => {
    // Ensure SUPPORTIVE_MESSAGES is not empty before trying to access it
    if (SUPPORTIVE_MESSAGES && SUPPORTIVE_MESSAGES.length > 0) {
      const randomIndex = Math.floor(Math.random() * SUPPORTIVE_MESSAGES.length);
      setCurrentMessage(SUPPORTIVE_MESSAGES[randomIndex]);
    } else {
      setCurrentMessage("Wishing you strength and healing today."); // Fallback message
    }
  }, []);

  return (
    // For a floral background image, you could add:
    // style={{ backgroundImage: 'url(/path/to/your/calming-flower-image.jpg)', backgroundSize: 'cover', backgroundPosition: 'center' }}
    <div className="min-h-screen bg-gradient-to-br from-pink-100 via-rose-50 to-pink-50 flex flex-col items-center justify-center p-4 selection:bg-pink-300 selection:text-white">
      <header className="text-center mb-10 md:mb-12">
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-playfair font-bold text-pink-600 tracking-tight">
          To My Dear Friend,
        </h1>
        <p className="text-xl md:text-2xl text-pink-500 mt-2 font-lora italic">
          Wishing You Strength & A Swift Recovery
        </p>
      </header>
      
      <main className="w-full flex flex-col items-center px-4">
        {currentMessage ? (
          <SupportiveMessageCard message={currentMessage} />
        ) : (
          <p className="text-rose-500 font-lora italic">Loading a thoughtful message for you...</p>
        )}

        <section className="mt-10 md:mt-12 p-6 md:p-8 bg-white/70 backdrop-blur-sm shadow-lg rounded-xl max-w-xl w-full text-center border border-pink-200/50" aria-labelledby="memories-title">
          <h2 id="memories-title" className="text-2xl md:text-3xl font-playfair font-semibold text-pink-500 mb-4">
            Brighter Days & Good Times Ahead
          </h2>
          <p className="text-gray-700 font-lora text-lg leading-relaxed">
            Thinking of all the good times we've shared and looking forward to many more. This space is for happy thoughts and anticipation of future adventures together.
          </p>
        </section>
      </main>

      <footer className="mt-10 md:mt-12 text-center text-sm text-pink-500/80 font-lora">
        <p>Sending you my warmest wishes for your well-being.</p>
        <p>&copy; {new Date().getFullYear()} - Created with care, for a dear friend.</p>
      </footer>
    </div>
  );
};

export default App;