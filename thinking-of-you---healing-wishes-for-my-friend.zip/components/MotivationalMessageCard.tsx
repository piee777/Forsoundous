import React from 'react';

interface SupportiveMessageCardProps {
  message: string;
}

// A more neutral, uplifting icon
const SparkleIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 24 24" 
    fill="currentColor" 
    className={`w-6 h-6 ${className}`}
    aria-hidden="true"
  >
    <path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.006 5.404.434c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354l-4.502 2.825c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.434L10.788 3.21z" clipRule="evenodd" />
  </svg>
);


export const SupportiveMessageCard: React.FC<SupportiveMessageCardProps> = ({ message }) => {
  if (!message) {
    return null;
  }

  return (
    <div 
      className="bg-white/90 backdrop-blur-sm shadow-xl rounded-xl p-6 md:p-8 max-w-xl w-full mx-auto border border-pink-200/50 transform transition-all hover:scale-[1.02] duration-300 ease-in-out"
      role="article"
      aria-label="Supportive Message"
    >
      <div className="flex flex-col items-center text-center">
        <SparkleIcon className="text-amber-500 mb-4 w-8 h-8" /> {/* Changed icon and color */}
        <p className="text-xl md:text-2xl text-rose-700 font-lora leading-relaxed italic">
          "{message}"
        </p>
      </div>
    </div>
  );
};