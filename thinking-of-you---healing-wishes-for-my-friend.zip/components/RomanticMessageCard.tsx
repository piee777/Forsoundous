import React from 'react';

interface RomanticMessageCardProps {
  message: string;
}

const HeartIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 24 24" 
    fill="currentColor" 
    className={`w-6 h-6 ${className}`}
    aria-hidden="true"
  >
    <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
  </svg>
);

export const RomanticMessageCard: React.FC<RomanticMessageCardProps> = ({ message }) => {
  if (!message) {
    return null;
  }

  return (
    <div 
      className="bg-white/90 backdrop-blur-sm shadow-xl rounded-xl p-6 md:p-8 max-w-xl w-full mx-auto border border-pink-200/50 transform transition-all hover:scale-[1.02] duration-300 ease-in-out"
      role="article"
      aria-label="Romantic Message"
    >
      <div className="flex flex-col items-center text-center">
        <HeartIcon className="text-pink-400 mb-4 w-8 h-8" />
        <p className="text-xl md:text-2xl text-rose-700 font-lora leading-relaxed italic">
          "{message}"
        </p>
      </div>
    </div>
  );
};